﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for προπαίδειες.xaml
    /// </summary>

    public partial class προπαίδειες : Window
    {

        public προπαίδειες()
        {
            InitializeComponent();
        }
        void prop_at_text(int prop_number)
        {
            string propaideia = "";
            for (int i = 1; i <= 10; i++)
            {
                propaideia += i + " x " + prop_number + " = " + i * prop_number + "\n";
            }
            prop.Text = propaideia;
        }
        public int i;
        public static bool revision; // to xreiazomaste gia na ksexwrisume thn propaideia tou 10 apo thn epanalhpsh
        public static int q1;
        public static int q2;
        public static int q3;
        public static int q4;
        public static int q5;
        public static int q6;
        public static int q7;
        public static int q8;
        public static int q9;
        public static int q10;
        public static Dictionary<int,int> revision_stats = new Dictionary<int, int>();
        public static Dictionary<int, int> revision_quest = new Dictionary<int, int>();
        private void Next_Click(object sender, RoutedEventArgs e)
        {
            i += 1;
            if (i == 10)
            {
                next.Visibility = Visibility.Hidden;
                test_all.Visibility = Visibility.Visible;
            }
            else
            {
                next.Visibility = Visibility.Visible;
                test_all.Visibility = Visibility.Hidden;
            }
            if (i != 1)
            {
                previous.Visibility = Visibility.Visible;
            }
            label.Content = "του " + i.ToString();
            prop_at_text(i);
        }

        private void Previous_Click(object sender, RoutedEventArgs e)
        {
            i = i - 1;
            if (i != 10)
            {
                next.Visibility = Visibility.Visible;
            }
            test_all.Visibility = Visibility.Hidden;
            if (i != 1)
            {
                previous.Visibility = Visibility.Visible;
            }
            else
            {
                previous.Visibility = Visibility.Hidden;
            }

            label.Content = "του " + i.ToString();
            prop_at_text(i);
        }
        static Random random = new Random();
        int RandomNumber1, RandomNumber2, RandomNumber3, RandomNumber4, RandomNumber5;
        int RandomNumber6, RandomNumber7, RandomNumber8, RandomNumber9, RandomNumber10;

        // Generate and display 5 random integers between 0 and 100.
        public int Create_Numbers()
        {
            // List<int> integers = new List<int>();
            int[] integers = new int[11];
            Console.WriteLine("Ten random integers between 1 and 10:");
            for (int ctr = 1; ctr <= 10; ctr++)
            {
                // Console.Write("{0,8:N0}", random.Next(11));
                //integers.Add(random.Next(11));
                integers[ctr] = random.Next(1, 11);

            }
            //Console.WriteLine(integers);
            //Console.WriteLine(integers[1]);
            try
            {
                revision_stats.Add(integers[2], 0);
                revision_quest.Add(integers[2], 0);
            }
            catch
            {
                revision_quest[integers[2]] = 0;
            }
            return integers[2];

        }

        private void Do_test(object sender, RoutedEventArgs e)
        {
            var newtest = new test();
            newtest.number.Content = "στην προπαίδεια του " + i;

            /*   RandomNumber1 = random.Next(1, 10);
             newtest.q1.Content = "1) " + myIntArray[RandomNumber1] + " x " + i;
             newtest.right_answer1 = RandomNumber1 * i;

            var exclude = new HashSet<int>() { RandomNumber1};
              //do
             // {
                 RandomNumber2 = random.Next(1, 10 - exclude.Count);
             // } while(RandomNumber2==RandomNumber1);
              newtest.q2.Content = "2) " + RandomNumber2 + " x " + i;
              newtest.right_answer2 = RandomNumber2 * i;
              exclude = new HashSet<int>() { RandomNumber1,RandomNumber2};
              // do
              // {
              RandomNumber3 = random.Next(1, 10);
             // }while((RandomNumber3 == RandomNumber1)||(RandomNumber3==RandomNumber2));
              newtest.q3.Content = "3) " + RandomNumber3 + " x " + i;
              newtest.right_answer3 = RandomNumber3 * i;
              exclude = new HashSet<int>() { RandomNumber1, RandomNumber2, RandomNumber3};

              //do
              //{
              RandomNumber4 = random.Next(1, 10);
             // }while((RandomNumber4==RandomNumber1)||(RandomNumber4==RandomNumber2)||(RandomNumber4==RandomNumber3));
              newtest.q4.Content = "4) " + RandomNumber4 + " x " + i;
              newtest.right_answer4 = RandomNumber4 * i;
              do
              {
                 RandomNumber5 = random.Next(1, 10);
              } while((RandomNumber5==RandomNumber1)||(RandomNumber5==RandomNumber2)||(RandomNumber5==RandomNumber3)||(RandomNumber5==RandomNumber4));
              newtest.q5.Content = "5) " + RandomNumber5 + " x " + i;
              newtest.right_answer5 = RandomNumber5 * i;
              do
              {
                RandomNumber6 = random.Next(1, 10);
              }while((RandomNumber6==RandomNumber1)||(RandomNumber6==RandomNumber2)||(RandomNumber6==RandomNumber3)||(RandomNumber6==RandomNumber4)||(RandomNumber6==RandomNumber5));
              newtest.q6.Content = "6) " + RandomNumber6 + " x " + i;
              newtest.right_answer6 = RandomNumber6 * i;
              do
              {
                RandomNumber7 = random.Next(1, 10);
              }while((RandomNumber7==RandomNumber1)||(RandomNumber7==RandomNumber2)||(RandomNumber7==RandomNumber3)||(RandomNumber7==RandomNumber4)||(RandomNumber7==RandomNumber5)||(RandomNumber7==RandomNumber6));
              newtest.q7.Content = "7) " + RandomNumber7 + " x " + i;
              newtest.right_answer7 = RandomNumber7 * i;
             do
              {
                RandomNumber8 = random.Next(1, 10);
              } while((RandomNumber8==RandomNumber1)||(RandomNumber8==RandomNumber2)||(RandomNumber8==RandomNumber3)||(RandomNumber8==RandomNumber4)||(RandomNumber8==RandomNumber5)||(RandomNumber8==RandomNumber6)||(RandomNumber8==RandomNumber7));
              newtest.q8.Content = "8) " + RandomNumber8 + " x " + i;
              newtest.right_answer8 = RandomNumber8 * i;
             do
              {
                RandomNumber9 = random.Next(1, 10);
              } while((RandomNumber9==RandomNumber1)||(RandomNumber9==RandomNumber2)||(RandomNumber9==RandomNumber3)||(RandomNumber9==RandomNumber4)||(RandomNumber9==RandomNumber5)||(RandomNumber9==RandomNumber6)||(RandomNumber9==RandomNumber7)||(RandomNumber9==RandomNumber8));
              newtest.q9.Content = "9) " + RandomNumber9 + " x " + i;
              newtest.right_answer9 = RandomNumber9 * i;
              var exclude = new HashSet<int>() {RandomNumber1,RandomNumber2,RandomNumber3,RandomNumber4,RandomNumber5,RandomNumber6,RandomNumber7,RandomNumber8, RandomNumber9 };
              RandomNumber10= random.Next(1, 10 - exclude.Count);
              newtest.q10.Content = "10) " + RandomNumber10 + " x " + i;
              newtest.right_answer10 = RandomNumber10 * i;
               do
               {
                 RandomNumber10 = random.Next(1, 10);
               } while ((RandomNumber10 == RandomNumber1) || (RandomNumber10 == RandomNumber2) || (RandomNumber10 == RandomNumber3) || (RandomNumber10 == RandomNumber4) || (RandomNumber10 == RandomNumber5) || (RandomNumber10 == RandomNumber6) || (RandomNumber10 == RandomNumber7) || (RandomNumber10 == RandomNumber8) || (RandomNumber10 == RandomNumber9));
               newtest.q10.Content = "10) " + RandomNumber10 + " x " + i;
               newtest.right_answer10 = RandomNumber10 * i;*/
            newtest.q1.Content = "1) " + 1 + " x " + i;
            newtest.right_answer1 = 1 * i;
            newtest.q2.Content = "2) " + 2 + " x " + i;
            newtest.right_answer2 = 2 * i;
            newtest.q3.Content = "3) " + 3 + " x " + i;
            newtest.right_answer3 = 3 * i;
            newtest.q4.Content = "4) " + 4 + " x " + i;
            newtest.right_answer4 = 4 * i;
            newtest.q5.Content = "5) " + 5 + " x " + i;
            newtest.right_answer5 = 5 * i;
            newtest.q6.Content = "6) " + 6 + " x " + i;
            newtest.right_answer6 = 6 * i;
            newtest.q7.Content = "7) " + 7 + " x " + i;
            newtest.right_answer7 = 7 * i;
            newtest.q8.Content = "8) " + 8 + " x " + i;
            newtest.right_answer8 = 8 * i;
            newtest.q9.Content = "9) " + 9 + " x " + i;
            newtest.right_answer9 = 9 * i;
            newtest.q10.Content = "10) " + 10 + " x " + i;
            newtest.right_answer10 = 10 * i;
            newtest.Show();
        }
        private void Log_out(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("done");
        }
        private void Do_test_all(object sender, RoutedEventArgs e)
        { 
             q1 = Create_Numbers();
             q2 = Create_Numbers();
             q3 = Create_Numbers();
             q4 = Create_Numbers();
             q5 = Create_Numbers();
             q6 = Create_Numbers();
             q7 = Create_Numbers();
             q8 = Create_Numbers();
             q9 = Create_Numbers();
             q10 = Create_Numbers();

            revision = true;
            var newtest = new test();
            newtest.retake.Visibility = Visibility.Visible;
            newtest.number.Content = "Σε όλη την προπαίδεια";
            newtest.q1.Content = "1) " + 1 + " x " + q1;
            newtest.right_answer1 = 1 * q1;
            newtest.q2.Content = "2) " + 2 + " x " + q2;
            newtest.right_answer2 = 2 * q2;
            newtest.q3.Content = "3) " + 6 + " x " + q3;
            newtest.right_answer3 = 6 * q3;
            newtest.q4.Content = "4) " + 2 + " x " + q4;
            newtest.right_answer4 = 2 * q4;
            newtest.q5.Content = "5) " + 10 + " x " + q5;
            newtest.right_answer5 = 10 * q5;
            newtest.q6.Content = "6) " + 6 + " x " + q6;
            newtest.right_answer6 = 6 * q6;
            newtest.q7.Content = "7) " + 7 + " x " + q7;
            newtest.right_answer7 = 7 * q7;
            newtest.q8.Content = "8) " + 4 + " x " + q8;
            newtest.right_answer8 = 4 * q8;
            newtest.q9.Content = "9) " + 9 + " x " + q9;
            newtest.right_answer9 = 9 * q9;
            newtest.q10.Content = "10) " + 1 + " x " + q10;
            newtest.right_answer10 = 1 * q10;
            newtest.Show();
        
        }
        public static bool Get_Revision()
        {

            // MessageBox.Show(logged.ToString());
            return revision;
        }

    }
}
