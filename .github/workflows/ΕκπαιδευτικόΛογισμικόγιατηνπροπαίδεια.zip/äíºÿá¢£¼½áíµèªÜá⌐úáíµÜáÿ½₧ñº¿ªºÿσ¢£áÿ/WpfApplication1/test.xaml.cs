﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;


namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for test.xaml
    /// </summary>
    public partial class test : Window
    {
        public test()
        {           
            InitializeComponent();
        }
         public int right_answer1;
         public int right_answer2;
         public int right_answer3;
         public int right_answer4;
         public int right_answer5;
         public int right_answer6;
         public int right_answer7;
         public int right_answer8;
         public int right_answer9;
         public int right_answer10;
         public int i;
         int an,apotelesmata,erwthseis;
        
        private void Answer1(object sender, KeyEventArgs e)
         {
            string answer1 = an1.Text;
            if((e.Key == System.Windows.Input.Key.Enter))
            {
                if (String.IsNullOrEmpty(an1.Text))
                {
                    MessageBox.Show("Πληκτρολόγησε την απάντηση σου!");
                }
                else if(!int.TryParse(an1.Text, out an))
                {
                    MessageBox.Show("Η απάντηση πρέπει να είναι αριθμός!!");
                }
                else
                {
                    erwthseis += 1;
                    an = int.Parse(answer1);
                    if (right_answer1 == an)
                    {
                        an1.Background = Brushes.Green;
                        progressBar1.Value += 10;
                        apotelesmata += 1;
                    }
                    else
                    {
                        an1.Background = Brushes.Red;
                    }
                    an1.IsEnabled = false;
                }
            }
         }
        private void Answer2(object sender, KeyEventArgs e)
        {
            string answer2 = an2.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                if (String.IsNullOrEmpty(an2.Text))
                {
                    MessageBox.Show("Πληκτρολόγησε την απάντηση σου!");
                }
                else if (!int.TryParse(an2.Text, out an))
                {
                    MessageBox.Show("Η απάντηση πρέπει να είναι αριθμός!!");
                }
                else
                {
                    erwthseis += 1;
                    an = int.Parse(answer2);
                    if (right_answer2 == an)
                    {
                        an2.Background = Brushes.Green;
                        progressBar1.Value += 10;
                        apotelesmata += 1;
                    }
                    else
                    {
                        an2.Background = Brushes.Red;
                    }
                    an2.IsEnabled = false;
                }
            }
        }
        private void Answer3(object sender, KeyEventArgs e)
        {
            string answer3 = an3.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                if (String.IsNullOrEmpty(an3.Text))
                {
                    MessageBox.Show("Πληκτρολόγησε την απάντηση σου!");
                }
                else if (!int.TryParse(an3.Text, out an))
                {
                    MessageBox.Show("Η απάντηση πρέπει να είναι αριθμός!!");
                }
                else
                {
                    erwthseis += 1;
                    an = int.Parse(answer3);
                    if (right_answer3 == an)
                    {
                        an3.Background = Brushes.Green;
                        progressBar1.Value += 10;
                        apotelesmata += 1;

                    }
                    else
                    {
                        an3.Background = Brushes.Red;
                    }
                    an3.IsEnabled = false;
                }
            }
        }
        private void Answer4(object sender, KeyEventArgs e)
        {
            string answer4 = an4.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                if (String.IsNullOrEmpty(an4.Text))
                {
                    MessageBox.Show("Πληκτρολόγησε την απάντηση σου!");
                }
                else if (!int.TryParse(an4.Text, out an))
                {
                    MessageBox.Show("Η απάντηση πρέπει να είναι αριθμός!!");
                }
                else
                {
                    erwthseis += 1;
                    an = int.Parse(answer4);
                    if (right_answer4 == an)
                    {
                        an4.Background = Brushes.Green;
                        progressBar1.Value += 10;
                        apotelesmata += 1;

                    }
                    else
                    {
                        an4.Background = Brushes.Red;
                    }
                    an4.IsEnabled = false;
                }
            }
        }
        private void Answer5(object sender, KeyEventArgs e)
        {
            string answer5 = an5.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                if (String.IsNullOrEmpty(an5.Text))
                {
                    MessageBox.Show("Πληκτρολόγησε την απάντηση σου!");
                }
                else if (!int.TryParse(an5.Text, out an))
                {
                    MessageBox.Show("Η απάντηση πρέπει να είναι αριθμός!!");
                }
                else
                {
                    erwthseis += 1;
                    an = int.Parse(answer5);
                    if (right_answer5 == an)
                    {
                        an5.Background = Brushes.Green;
                        progressBar1.Value += 10;
                        apotelesmata += 1;
                    }
                    else
                    {
                        an5.Background = Brushes.Red;
                    }
                    an5.IsEnabled = false;
                }
            }
        }
        private void Answer6(object sender, KeyEventArgs e)
        {
            string answer6 = an6.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                if (String.IsNullOrEmpty(an6.Text))
                {
                    MessageBox.Show("Πληκτρολόγησε την απάντηση σου!");
                }
                else if (!int.TryParse(an6.Text, out an))
                {
                    MessageBox.Show("Η απάντηση πρέπει να είναι αριθμός!!");
                }
                else
                {
                    erwthseis += 1;
                    an = int.Parse(answer6);
                    if (right_answer6 == an)
                    {
                        an6.Background = Brushes.Green;
                        progressBar1.Value += 10;
                        apotelesmata += 1;
                    }
                    else
                    {
                        an6.Background = Brushes.Red;
                    }
                    an6.IsEnabled = false;
                }
            }
        }
        private void Answer7(object sender, KeyEventArgs e)
        {
            string answer7 = an7.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                if (String.IsNullOrEmpty(an7.Text))
                {
                    MessageBox.Show("Πληκτρολόγησε την απάντηση σου!");
                }
                else if (!int.TryParse(an7.Text, out an))
                {
                    MessageBox.Show("Η απάντηση πρέπει να είναι αριθμός!!");
                }
                else
                {
                    erwthseis += 1;
                    an = int.Parse(answer7);
                    if (right_answer7 == an)
                    {
                        an7.Background = Brushes.Green;
                        progressBar1.Value += 10;
                        apotelesmata += 1;
                    }
                    else
                    {
                        an7.Background = Brushes.Red;
                    }
                    an7.IsEnabled = false;
                }
            }
        }
        private void Answer8(object sender, KeyEventArgs e)
        {
            string answer8 = an8.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                if (String.IsNullOrEmpty(an8.Text))
                {
                    MessageBox.Show("Πληκτρολόγησε την απάντηση σου!");
                }
                else if (!int.TryParse(an8.Text, out an))
                {
                    MessageBox.Show("Η απάντηση πρέπει να είναι αριθμός!!");
                }
                else
                {
                    erwthseis += 1;
                    an = int.Parse(answer8);
                    if (right_answer8 == an)
                    {
                        an8.Background = Brushes.Green;
                        progressBar1.Value += 10;
                        apotelesmata += 1;
                    }
                    else
                    {
                        an8.Background = Brushes.Red;
                    }
                    an8.IsEnabled = false;
                }
            }
        }
        private void Answer9(object sender, KeyEventArgs e)
        {
            string answer9 = an9.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                if (String.IsNullOrEmpty(an9.Text))
                {
                    MessageBox.Show("Πληκτρολόγησε την απάντηση σου!");
                }
                else if (!int.TryParse(an9.Text, out an))
                {
                    MessageBox.Show("Η απάντηση πρέπει να είναι αριθμός!!");
                }
                else
                {
                    erwthseis += 1;
                    an = int.Parse(answer9);
                    if (right_answer9 == an)
                    {
                        an9.Background = Brushes.Green;
                        progressBar1.Value += 10;
                        apotelesmata += 1;
                    }
                    else
                    {
                        an9.Background = Brushes.Red;
                    }
                    an9.IsEnabled = false;
                }
            }
        }
        private void Answer10(object sender, KeyEventArgs e)
        {
            string answer10 = an10.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                if (String.IsNullOrEmpty(an10.Text))
                {
                    MessageBox.Show("Πληκτρολόγησε την απάντηση σου!");
                }
                else if (!int.TryParse(an10.Text, out an))
                {
                    MessageBox.Show("Η απάντηση πρέπει να είναι αριθμός!!");
                }
                else
                {
                    erwthseis += 1;
                    an = int.Parse(answer10);
                    if (right_answer10 == an)
                    {
                        an10.Background = Brushes.Green;
                        progressBar1.Value += 10;
                        apotelesmata += 1;
                    }
                    else
                    {
                        an10.Background = Brushes.Red;
                    }
                    an10.IsEnabled = false;
                }
            }
        }

        private void Log_out(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("done");
        }

        private void Hoverr(object sender, MouseEventArgs e)
        {
            if(erwthseis==10)
            {
             results.Cursor = Cursors.Hand;
            }
            else
            {
                MessageBox.Show("Δεν έχεις απαντήσει κάποιες ερωτήσεις");
            }
        }

        private void Store_Results(object sender, System.EventArgs e)
        {
            //we define i in the propaideies class
            //and we need to pass it through to test()
            //so as to save progress data in the database
            //related to the specific number for which 
            //we are doing the test -> Store_InDB(int number)
            int number = MainWindow.prop_number;
           // this is for debugging MessageBox.Show(number.ToString());
            Store_InDB(number);
            // so after we store the progress to the database
            // we do not want the user to go and redo the test
            // so we make the answers ReadOnly
            an1.IsReadOnly = true;
            an2.IsReadOnly = true;
            an3.IsReadOnly = true;
            an4.IsReadOnly = true;
            an5.IsReadOnly = true;
            an6.IsReadOnly = true;
            an7.IsReadOnly = true;
            an8.IsReadOnly = true;
            an9.IsReadOnly = true;
            an10.IsReadOnly = true;
        }

        public void Store_InDB(int number)
        {
            // need to create an object reference 
            // to get the username
            // so create an instance of Αρχική
            // here in the calling method
            // so as to be able to access the 
            // wanted variable -> username

            //  Αρχική user = new Αρχική();
            // string logged = user.
            // MessageBox.Show(logged.ToString());
            string logged =  Αρχική.Get_Username();
           // this is for debbugging MessageBox.Show(logged.ToString());

            string connStr = @"server=localhost;userid=root;password=root;database=testdb";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");//this is used for debug purposes
                conn.Open();
                string usernametest = "test1";
                string sql = "update testdb.stats set prop" + number + "=" + apotelesmata + " WHERE username=" + '"' + $"{ logged }" + '"';
                Console.WriteLine(sql);
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();
                Console.WriteLine(rdr); //this is used for debug purposes
                Console.WriteLine(apotelesmata);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString()); //this is used for debug purposes
            }
            conn.Close();
            Console.WriteLine("Done."); //this is used for debug purposes
        }
    }
}
