﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using MySql.Data.MySqlClient;


namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        void anathesi(int but_number)
        {
            string propaideia = "";
            var newForm = new προπαίδειες();
            if (logIn==true)
            {
                newForm.test.Visibility = Visibility.Visible;
                newForm.logout.Visibility = Visibility.Visible;
            }
            newForm.label.Content = "του "+ but_number;
            newForm.Title = "Προπαίδεια του " + but_number;
            if(but_number==1)
            {
                newForm.previous.Visibility = Visibility.Hidden;
            }
            else if(but_number==10)
            {
                newForm.next.Visibility = Visibility.Hidden;
            }
            else
            {
                newForm.previous.Visibility = Visibility.Visible;
                newForm.next.Visibility = Visibility.Visible;
            }
            for (int i = 1; i <= 10; i++)
            {
                propaideia += i + " x "+ but_number + " = " + i * but_number + "\n";
            }
            newForm.prop.Text = propaideia;
            newForm.i = but_number;
           
            newForm.Show();
         }
        public MainWindow()
        {
            InitializeComponent();
           
        }
        Boolean logIn = false;     
        private void Button1_Click(object sender, RoutedEventArgs e)
        {
           anathesi(1);
        }
        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            anathesi(2);
        }
        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            anathesi(3);
        }
        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            anathesi(4);
        }
        private void Button5_Click(object sender, RoutedEventArgs e)
        {
            anathesi(5);
        }
        private void Button6_Click(object sender, RoutedEventArgs e)
        {
            anathesi(6);
        }
        private void Button7_Click(object sender, RoutedEventArgs e)
        {
            anathesi(7);
        }
        private void Button8_Click(object sender, RoutedEventArgs e)
        {
            anathesi(8);
        }
        private void Button9_Click(object sender, RoutedEventArgs e)
        {
            anathesi(9);
        }
        private void Button10_Click(object sender, RoutedEventArgs e)
        {
            anathesi(10);
        }

        //private void Log_In(object sender, RoutedEventArgs e)
       // {
        //    logIn = true;
       // }

        private void Log_In(object sender, System.EventArgs e)
        {
            string connStr = @"server=localhost;userid=root;password=root;database=testdb";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");//this is used for debug purposes
                conn.Open();

                string sql = "select username,pass from testdb.users WHERE username=" + '"' + $"{ UsernameBox.Text }" + '"' + " AND pass=" + '"' + $"{ passwordBox.Password }" + '"';
                Console.WriteLine(sql);
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();
                bool res = rdr.Read();
                logIn = res;
                Console.WriteLine(res); //this is used for debug purposes
                Console.WriteLine(UsernameBox); //this is used for debug purposes
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString()); //this is used for debug purposes
            }
            conn.Close();
            Console.WriteLine("Done."); //this is used for debug purposes
            MessageBox.Show("Login Successful!");
            UsernameBox.Visibility = Visibility.Hidden;
            passwordBox.Visibility = Visibility.Hidden;
            log_in.Visibility = Visibility.Hidden;
        }
    }
}
