﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;


namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for test.xaml
    /// </summary>
    public partial class test : Window
    {
        public test()
        {
            InitializeComponent();
            Store_InDB();
        }
         public int right_answer1;
         public int right_answer2;
         public int right_answer3;
         public int right_answer4;
         public int right_answer5;
         public int right_answer6;
         public int right_answer7;
         public int right_answer8;
         public int right_answer9;
         public int right_answer10;
         public int i;
         int an;
         private void Answer1(object sender, KeyEventArgs e)
         {
            string answer1 = an1.Text;
            if((e.Key == System.Windows.Input.Key.Enter))
            {
              an = int.Parse(answer1);
              if (right_answer1==an)
              {
                  an1.Background = Brushes.Green;
                   progressBar1.Value += 10;
                    //progressBar1
                  
              }
              else
              {
                an1.Background = Brushes.Red;
              }
                an1.IsEnabled = false;
            }
         }
        private void Answer2(object sender, KeyEventArgs e)
        {
            string answer2 = an2.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                an = int.Parse(answer2);
                if (right_answer2 == an)
                {
                    an2.Background = Brushes.Green;
                    progressBar1.Value += 10;

                }
                else
                {
                    an2.Background = Brushes.Red;
                }
                an2.IsEnabled = false;
            }
        }
        private void Answer3(object sender, KeyEventArgs e)
        {
            string answer3 = an3.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                an = int.Parse(answer3);
                if (right_answer3 == an)
                {
                    an3.Background = Brushes.Green;
                    progressBar1.Value += 10;

                }
                else
                {
                    an3.Background = Brushes.Red;
                }
                an3.IsEnabled = false;
            }
        }
        private void Answer4(object sender, KeyEventArgs e)
        {
            string answer4 = an4.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                an = int.Parse(answer4);
                if (right_answer4 == an)
                {
                    an4.Background = Brushes.Green;
                    progressBar1.Value += 10;

                }
                else
                {
                    an4.Background = Brushes.Red;
                }
                an4.IsEnabled = false;
            }
        }
        private void Answer5(object sender, KeyEventArgs e)
        {
            string answer5 = an5.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                an = int.Parse(answer5);
                if (right_answer5 == an)
                {
                    an5.Background = Brushes.Green;
                    progressBar1.Value += 10;

                }
                else
                {
                    an5.Background = Brushes.Red;
                }
                an5.IsEnabled = false;
            }
        }
        private void Answer6(object sender, KeyEventArgs e)
        {
            string answer6 = an6.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                an = int.Parse(answer6);
                if (right_answer6 == an)
                {
                    an6.Background = Brushes.Green;
                    progressBar1.Value += 10;

                }
                else
                {
                    an6.Background = Brushes.Red;
                }
                an6.IsEnabled = false;
            }
        }
        private void Answer7(object sender, KeyEventArgs e)
        {
            string answer7 = an7.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                an = int.Parse(answer7);
                if (right_answer1 == an)
                {
                    an7.Background = Brushes.Green;
                    progressBar1.Value += 10;

                }
                else
                {
                    an7.Background = Brushes.Red;
                }
                an7.IsEnabled = false;
            }
        }
        private void Answer8(object sender, KeyEventArgs e)
        {
            string answer8 = an8.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                an = int.Parse(answer8);
                if (right_answer8 == an)
                {
                    an8.Background = Brushes.Green;
                    progressBar1.Value += 10;

                }
                else
                {
                    an8.Background = Brushes.Red;
                }
                an8.IsEnabled = false;
            }
        }
        private void Answer9(object sender, KeyEventArgs e)
        {
            string answer9 = an9.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                an = int.Parse(answer9);
                if (right_answer9 == an)
                {
                    an9.Background = Brushes.Green;
                    progressBar1.Value += 10;

                }
                else
                {
                    an9.Background = Brushes.Red;
                }
                an9.IsEnabled = false;
            }
        }
        private void Answer10(object sender, KeyEventArgs e)
        {
            string answer10 = an10.Text;
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                an = int.Parse(answer10);
                if (right_answer1 == an)
                {
                    an10.Background = Brushes.Green;
                    progressBar1.Value += 10;

                }
                else
                {
                    an10.Background = Brushes.Red;
                }
                an10.IsEnabled = false;
            }
        }

        private void Log_out(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("done");
        }

        public void Store_InDB()
        {
            i += 1 ; // i is the number for this given test
            string connStr = @"server=localhost;userid=root;password=root;database=testdb";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");//this is used for debug purposes
                conn.Open();
                string usernametest = "p13111";
                string sql = "update testdb.stats set prop" + i + "=" + progressBar1.Value +" WHERE username=" + '"' + $"{ usernametest }" + '"';
                Console.WriteLine(sql);
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();
                Console.WriteLine(rdr); //this is used for debug purposes
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString()); //this is used for debug purposes
            }
            conn.Close();
            Console.WriteLine("Done."); //this is used for debug purposes
        }
    }
}
